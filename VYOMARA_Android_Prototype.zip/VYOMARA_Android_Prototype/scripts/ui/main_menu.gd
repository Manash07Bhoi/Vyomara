extends Control

const WORLD_SCENE := "res://scenes/world/FirstRealm.tscn"
const WORLD_IMAGE := "res://assets/reference_art/world_celestial_kingdom.webp"
const MUSIC := "res://assets/music/vyomara_original_synthetic_score.ogg"

func _ready() -> void:
    _build_ui()

func _build_ui() -> void:
    var bg := TextureRect.new()
    bg.name = "WorldBackdrop"
    bg.texture = load(WORLD_IMAGE)
    bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(bg)

    var shade := ColorRect.new()
    shade.color = Color(0.015, 0.025, 0.06, 0.54)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(shade)

    var center := CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    center.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    center.size_flags_vertical = Control.SIZE_EXPAND_FILL
    add_child(center)

    var stack := VBoxContainer.new()
    stack.custom_minimum_size = Vector2(600, 0)
    stack.add_theme_constant_override("separation", 15)
    center.add_child(stack)

    var eyebrow := _label("A VISION BY JP", 20, Color(0.94, 0.75, 0.38))
    eyebrow.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    stack.add_child(eyebrow)

    var title := _label("VYOMARA", 62, Color(1.0, 0.84, 0.49))
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.85))
    title.add_theme_constant_override("shadow_offset_x", 2)
    title.add_theme_constant_override("shadow_offset_y", 3)
    stack.add_child(title)

    var tagline := _label("ACROSS THE YUGAS. THROUGH THE REALMS.\nGUIDED BY DHARMA.", 16, Color(0.92, 0.91, 0.86))
    tagline.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    tagline.add_theme_constant_override("line_spacing", 5)
    stack.add_child(tagline)

    var gap := Control.new()
    gap.custom_minimum_size.y = 14
    stack.add_child(gap)

    var play := Button.new()
    play.text = "ENTER THE FIRST REALM"
    play.custom_minimum_size = Vector2(300, 58)
    play.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    play.add_theme_font_size_override("font_size", 18)
    play.add_theme_color_override("font_color", Color(0.06, 0.055, 0.04))
    play.add_theme_stylebox_override("normal", _button_style(Color(0.93, 0.73, 0.34), Color(1.0, 0.88, 0.54)))
    play.add_theme_stylebox_override("hover", _button_style(Color(1.0, 0.82, 0.43), Color(1.0, 0.92, 0.67)))
    play.add_theme_stylebox_override("pressed", _button_style(Color(0.76, 0.52, 0.2), Color(1.0, 0.88, 0.54)))
    play.pressed.connect(_start_game)
    stack.add_child(play)

    var disclosure := _label("ANDROID-FIRST PLAYABLE PROTOTYPE  •  CONCEPT ART + PROCEDURAL 3D\nORIGINAL MYTH-INSPIRED GAME ADAPTATION — NOT A SCRIPTURAL RECONSTRUCTION", 10, Color(0.84, 0.85, 0.9))
    disclosure.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    disclosure.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    stack.add_child(disclosure)

    var footer := _label("DEVELOPED BY JP  •  GODOT 4  •  OFFLINE DEMO", 12, Color(0.89, 0.75, 0.47))
    footer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    stack.add_child(footer)

    var music := AudioStreamPlayer.new()
    music.stream = load(MUSIC)
    music.volume_db = -12.0
    add_child(music)
    music.finished.connect(func(): music.play())
    music.play()

    var fade := ColorRect.new()
    fade.color = Color(0.008, 0.012, 0.028, 1.0)
    fade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(fade)
    var tween := create_tween()
    tween.tween_property(fade, "color:a", 0.0, 1.0)
    tween.tween_callback(fade.queue_free)

func _start_game() -> void:
    var err := get_tree().change_scene_to_file(WORLD_SCENE)
    if err != OK:
        push_error("Could not load FirstRealm scene: %s" % err)

func _label(text_value: String, font_size: int, color: Color) -> Label:
    var label := Label.new()
    label.text = text_value
    label.add_theme_font_size_override("font_size", font_size)
    label.add_theme_color_override("font_color", color)
    label.add_theme_color_override("font_outline_color", Color(0.015, 0.02, 0.04, 0.9))
    label.add_theme_constant_override("outline_size", 2)
    return label

func _button_style(fill: Color, border_color: Color) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = fill
    style.border_color = border_color
    style.set_border_width_all(2)
    style.set_corner_radius_all(12)
    style.content_margin_left = 18
    style.content_margin_right = 18
    style.content_margin_top = 10
    style.content_margin_bottom = 10
    return style
