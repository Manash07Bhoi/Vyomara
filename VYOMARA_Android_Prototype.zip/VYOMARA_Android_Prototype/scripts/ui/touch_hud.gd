extends CanvasLayer
const JOYSTICK_SCRIPT := preload("res://scripts/ui/virtual_joystick.gd")
var hero: CharacterBody3D
var world: Node
var root: Control
var objective_label: Label
var status_label: Label
var health_bar: ProgressBar
var enemy_bar: ProgressBar
var enemy_title: Label
var overlay_layer: Control
var _notice_timer := 0.0

func bind(hero_ref: CharacterBody3D, world_ref: Node) -> void:
    hero=hero_ref;world=world_ref
    _build_ui()

func _build_ui() -> void:
    root=Control.new();root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);root.mouse_filter=Control.MOUSE_FILTER_PASS;add_child(root)
    var top_panel:=Panel.new();top_panel.position=Vector2(18,16);top_panel.size=Vector2(365,112);top_panel.add_theme_stylebox_override("panel",_panel_style(Color(0.025,0.035,0.06,0.78),Color(0.68,0.51,0.23,0.8)));root.add_child(top_panel)
    var title:=_label("THE FIRST LIGHT OF DHARMA",14,Color(1.0,0.82,0.46));title.position=Vector2(16,10);title.size=Vector2(330,26);top_panel.add_child(title)
    objective_label=_label("Defeat the Shadow Sentinel",16,Color(0.94,0.94,0.92));objective_label.position=Vector2(16,36);objective_label.size=Vector2(330,24);top_panel.add_child(objective_label)
    var hp_text:=_label("VITALITY",10,Color(0.78,0.8,0.87));hp_text.position=Vector2(16,67);hp_text.size=Vector2(72,18);top_panel.add_child(hp_text)
    health_bar=ProgressBar.new();health_bar.position=Vector2(86,69);health_bar.size=Vector2(240,15);health_bar.max_value=100;health_bar.value=100;health_bar.show_percentage=false;health_bar.add_theme_stylebox_override("background",_panel_style(Color(0.06,0.07,0.1,1),Color(0.25,0.25,0.3,1)));health_bar.add_theme_stylebox_override("fill",_panel_style(Color(0.85,0.22,0.1,1),Color(1,0.5,0.16,1)));top_panel.add_child(health_bar)
    enemy_title=_label("SHADOW SENTINEL",11,Color(0.83,0.77,0.95));enemy_title.anchor_left=0.5;enemy_title.anchor_right=0.5;enemy_title.offset_left=-145;enemy_title.offset_right=145;enemy_title.offset_top=20;enemy_title.offset_bottom=40;enemy_title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;root.add_child(enemy_title)
    enemy_bar=ProgressBar.new();enemy_bar.anchor_left=0.5;enemy_bar.anchor_right=0.5;enemy_bar.offset_left=-130;enemy_bar.offset_right=130;enemy_bar.offset_top=44;enemy_bar.offset_bottom=56;enemy_bar.max_value=160;enemy_bar.value=160;enemy_bar.show_percentage=false;enemy_bar.add_theme_stylebox_override("background",_panel_style(Color(0.06,0.04,0.08,0.85),Color(0.45,0.32,0.6,0.8)));enemy_bar.add_theme_stylebox_override("fill",_panel_style(Color(0.46,0.18,0.74,1),Color(0.75,0.48,1,1)));root.add_child(enemy_bar)
    status_label=_label("",16,Color(1.0,0.88,0.57));status_label.anchor_left=0.5;status_label.anchor_right=0.5;status_label.offset_left=-270;status_label.offset_right=270;status_label.anchor_top=0.16;status_label.anchor_bottom=0.16;status_label.offset_top=0;status_label.offset_bottom=55;status_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;status_label.vertical_alignment=VERTICAL_ALIGNMENT_CENTER;status_label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;root.add_child(status_label)
    var joystick=Control.new();joystick.name="VirtualJoystick";joystick.set_script(JOYSTICK_SCRIPT);joystick.anchor_left=0.0;joystick.anchor_right=0.0;joystick.anchor_top=1.0;joystick.anchor_bottom=1.0;joystick.offset_left=24;joystick.offset_top=-178;joystick.offset_right=180;joystick.offset_bottom=-22;root.add_child(joystick);joystick.connect("vector_changed", _on_joystick_vector_changed)
    _make_action_button("DODGE","DODGE",Vector4(-238,-190,-134,-112),func(): hero.call("try_dodge"))
    _make_action_button("INTERACT","ACT",Vector4(-124,-190,-20,-112),func(): world.call("try_interact"))
    _make_action_button("DIVINE","PULSE",Vector4(-238,-104,-134,-24),func(): hero.call("try_divine_pulse"))
    _make_action_button("ATTACK","GADA",Vector4(-124,-104,-20,-24),func(): hero.call("try_attack"))
    var small:=_label("WASD / ARROWS TO MOVE  •  J ATTACK  •  K PULSE  •  E INTERACT  •  L DODGE",10,Color(0.82,0.83,0.87));small.anchor_left=0.5;small.anchor_right=0.5;small.anchor_top=1.0;small.anchor_bottom=1.0;small.offset_left=-260;small.offset_right=260;small.offset_top=-24;small.offset_bottom=-5;small.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;root.add_child(small)
    enemy_title.visible=true;enemy_bar.visible=true

func _on_joystick_vector_changed(value: Vector2) -> void:
    if is_instance_valid(hero):
        hero.call("set_touch_move_vector", value)

func set_objective(value: String) -> void:
    if is_instance_valid(objective_label): objective_label.text=value

func set_health(current: float, maximum: float) -> void:
    if is_instance_valid(health_bar): health_bar.max_value=maximum;health_bar.value=current

func set_enemy_health(current: float, maximum: float) -> void:
    if is_instance_valid(enemy_bar): enemy_bar.max_value=maximum;enemy_bar.value=current;enemy_bar.visible=current>0.0;enemy_title.visible=current>0.0

func notify(message: String) -> void:
    if not is_instance_valid(status_label): return
    status_label.text=message
    status_label.modulate.a=1.0
    var tween:=create_tween();tween.tween_interval(2.8);tween.tween_property(status_label,"modulate:a",0.0,0.5)

func show_intro() -> void:
    _show_overlay("THE FIRST LIGHT OF DHARMA","A myth-inspired gameplay adaptation.\nRestore the shrine. Protect the path.","BEGIN")

func show_victory() -> void:
    _show_overlay("FIRST LIGHT RESTORED","The shrine is awakened.\nYour progress has been saved offline.","PLAY AGAIN")

func show_failure() -> void:
    _show_overlay("THE JOURNEY PAUSES","Regain your strength and try again.","RETRY")

func _show_overlay(heading: String,body_text: String,button_text: String) -> void:
    if is_instance_valid(overlay_layer): overlay_layer.queue_free()
    overlay_layer=Control.new();overlay_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);overlay_layer.mouse_filter=Control.MOUSE_FILTER_STOP;root.add_child(overlay_layer)
    var shade:=ColorRect.new();shade.color=Color(0.008,0.013,0.028,0.82);shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);overlay_layer.add_child(shade)
    var center:=CenterContainer.new();center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);overlay_layer.add_child(center)
    var stack:=VBoxContainer.new();stack.custom_minimum_size=Vector2(460,0);stack.add_theme_constant_override("separation",14);center.add_child(stack)
    var h:=_label(heading,31,Color(1.0,0.82,0.45));h.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;stack.add_child(h)
    var b:=_label(body_text,16,Color(0.91,0.92,0.95));b.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;b.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;stack.add_child(b)
    var action:=Button.new();action.text=button_text;action.custom_minimum_size=Vector2(220,52);action.size_flags_horizontal=Control.SIZE_SHRINK_CENTER;action.add_theme_font_size_override("font_size",17);action.add_theme_stylebox_override("normal",_panel_style(Color(0.88,0.68,0.30,1),Color(1.0,0.88,0.55,1)));stack.add_child(action)
    if heading=="THE FIRST LIGHT OF DHARMA":
        action.pressed.connect(func(): overlay_layer.queue_free();overlay_layer=null)
    elif heading=="FIRST LIGHT RESTORED":
        action.pressed.connect(func(): world.call("restart_level"))
    else:
        action.pressed.connect(func(): world.call("restart_level"))
    var menu:=Button.new();menu.text="RETURN TO TITLE";menu.custom_minimum_size=Vector2(220,44);menu.size_flags_horizontal=Control.SIZE_SHRINK_CENTER;menu.flat=true;menu.add_theme_font_size_override("font_size",13);menu.pressed.connect(func(): world.call("return_to_menu"));stack.add_child(menu)

func _make_action_button(node_name: String,text_value: String,offsets: Vector4,callback: Callable) -> void:
    var button:=Button.new();button.name=node_name;button.text=text_value;button.custom_minimum_size=Vector2(104,78);button.anchor_left=1.0;button.anchor_right=1.0;button.anchor_top=1.0;button.anchor_bottom=1.0;button.offset_left=offsets.x;button.offset_top=offsets.y;button.offset_right=offsets.z;button.offset_bottom=offsets.w;button.add_theme_font_size_override("font_size",14);button.add_theme_color_override("font_color",Color(1.0,0.9,0.7));button.add_theme_stylebox_override("normal",_panel_style(Color(0.025,0.04,0.065,0.8),Color(0.77,0.58,0.26,0.8)));button.add_theme_stylebox_override("pressed",_panel_style(Color(0.42,0.25,0.09,0.92),Color(1.0,0.82,0.4,1)));button.pressed.connect(callback);root.add_child(button)

func _label(text_value: String,font_size: int,color: Color) -> Label:
    var label:=Label.new();label.text=text_value;label.add_theme_font_size_override("font_size",font_size);label.add_theme_color_override("font_color",color);label.add_theme_color_override("font_outline_color",Color(0.02,0.025,0.05,0.95));label.add_theme_constant_override("outline_size",2);return label

func _panel_style(fill: Color,border: Color) -> StyleBoxFlat:
    var style:=StyleBoxFlat.new();style.bg_color=fill;style.border_color=border;style.set_border_width_all(1);style.set_corner_radius_all(10);style.content_margin_left=10;style.content_margin_right=10;style.content_margin_top=6;style.content_margin_bottom=6;return style
