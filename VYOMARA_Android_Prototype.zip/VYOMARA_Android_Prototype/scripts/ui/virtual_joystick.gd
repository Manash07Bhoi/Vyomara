extends Control
signal vector_changed(value: Vector2)

@export var radius: float = 60.0
var _finger_id: int = -1
var _axis := Vector2.ZERO
var _base := Vector2(78.0, 78.0)

func _ready() -> void:
    custom_minimum_size = Vector2(156, 156)
    mouse_filter = Control.MOUSE_FILTER_STOP
    queue_redraw()

func _draw() -> void:
    draw_circle(_base, radius + 10.0, Color(0.025, 0.035, 0.055, 0.42))
    draw_arc(_base, radius + 10.0, 0.0, TAU, 48, Color(0.85, 0.68, 0.34, 0.65), 2.0, true)
    draw_circle(_base, radius, Color(0.15, 0.18, 0.22, 0.48))
    draw_circle(_base + _axis * radius * 0.78, 25.0, Color(0.9, 0.73, 0.38, 0.78))
    draw_arc(_base + _axis * radius * 0.78, 25.0, 0.0, TAU, 32, Color(1.0, 0.9, 0.62, 0.95), 2.0, true)

func _gui_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed and _finger_id == -1:
            _finger_id = event.index
            _update_axis(event.position)
            accept_event()
        elif not event.pressed and event.index == _finger_id:
            _finger_id = -1
            _axis = Vector2.ZERO
            vector_changed.emit(_axis)
            queue_redraw()
            accept_event()
    elif event is InputEventScreenDrag and event.index == _finger_id:
        _update_axis(event.position)
        accept_event()
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed:
            _finger_id = -2
            _update_axis(event.position)
        else:
            _finger_id = -1
            _axis = Vector2.ZERO
            vector_changed.emit(_axis)
            queue_redraw()
    elif event is InputEventMouseMotion and _finger_id == -2:
        _update_axis(event.position)

func _update_axis(position: Vector2) -> void:
    _axis = ((position - _base) / radius).limit_length(1.0)
    vector_changed.emit(_axis)
    queue_redraw()
