extends CharacterBody3D
## Temporary, procedural, low-poly avatar proxy. Replace with an appropriately licensed,
## reviewed, rigged Hanuman model before public-facing release. This proxy is not final art.
signal health_changed(current: float, maximum: float)
signal defeated

@export var move_speed: float = 5.2
@export var dodge_speed: float = 9.0
@export var max_health: float = 100.0
var health: float = 100.0
var touch_move_vector := Vector2.ZERO
var world_controller
var _visual: Node3D
var _body_mesh: MeshInstance3D
var _arm_left: Node3D
var _arm_right: Node3D
var _leg_left: Node3D
var _leg_right: Node3D
var _attack_cooldown := 0.0
var _pulse_cooldown := 0.0
var _dodge_time := 0.0
var _invulnerability := 0.0
var _dead := false
var _anim_clock := 0.0

func _ready() -> void:
    add_to_group("player")
    health = max_health
    var collider := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.34
    capsule.height = 1.85
    collider.shape = capsule
    collider.position.y = 0.93
    add_child(collider)
    _create_visual()
    _create_camera()
    health_changed.emit(health, max_health)

func _create_visual() -> void:
    _visual = Node3D.new()
    _visual.name = "VisualProxy_REPLACE_WITH_LICENSED_HANUMAN_MODEL"
    _visual.position.y = 0.92
    add_child(_visual)
    var skin := _material(Color(0.47, 0.28, 0.17), 0.0, 0.88)
    var cloth := _material(Color(0.62, 0.105, 0.055), 0.0, 0.82)
    var gold := _material(Color(0.92, 0.62, 0.16), 0.72, 0.3, Color(0.35, 0.19, 0.025), 0.15)
    var dark := _material(Color(0.08, 0.055, 0.09), 0.55, 0.45)
    var eye := _material(Color(1.0, 0.55, 0.08), 0.1, 0.25, Color(1.0, 0.3, 0.02), 2.0)
    _mesh(_visual, "TorsoProxy", CapsuleMesh.new(), Vector3(0, 0.0, 0), Vector3(0.62, 0.72, 0.42), skin)
    _mesh(_visual, "DhotiProxy", CylinderMesh.new(), Vector3(0, -0.43, 0), Vector3(0.62, 0.42, 0.52), cloth)
    _mesh(_visual, "HeadProxy", SphereMesh.new(), Vector3(0, 0.71, -0.02), Vector3(0.48, 0.48, 0.43), skin)
    _mesh(_visual, "MuzzleProxy", SphereMesh.new(), Vector3(0, 0.58, -0.34), Vector3(0.27, 0.19, 0.18), _material(Color(0.66,0.43,0.28)))
    _mesh(_visual, "EarL", SphereMesh.new(), Vector3(-0.43, 0.77, -0.01), Vector3(0.17, 0.22, 0.10), skin)
    _mesh(_visual, "EarR", SphereMesh.new(), Vector3(0.43, 0.77, -0.01), Vector3(0.17, 0.22, 0.10), skin)
    _mesh(_visual, "EyeL", SphereMesh.new(), Vector3(-0.17, 0.76, -0.365), Vector3(0.065, 0.045, 0.035), eye)
    _mesh(_visual, "EyeR", SphereMesh.new(), Vector3(0.17, 0.76, -0.365), Vector3(0.065, 0.045, 0.035), eye)
    _mesh(_visual, "BrowCrownBand", CylinderMesh.new(), Vector3(0, 0.95, 0), Vector3(0.47, 0.12, 0.47), gold)
    _mesh(_visual, "CrownBase", CylinderMesh.new(), Vector3(0, 1.12, 0), Vector3(0.30, 0.25, 0.30), gold)
    _mesh(_visual, "CrownTip", SphereMesh.new(), Vector3(0, 1.34, 0), Vector3(0.12, 0.16, 0.12), gold)
    _mesh(_visual, "Tilak", SphereMesh.new(), Vector3(0, 0.91, -0.405), Vector3(0.045, 0.10, 0.025), _material(Color(0.92,0.25,0.08),0.0,0.45,Color(0.4,0.04,0.01),0.2))
    _mesh(_visual, "Necklace", TorusMesh.new(), Vector3(0, 0.27, -0.02), Vector3(0.26, 0.26, 0.26), gold)
    _mesh(_visual, "Belt", TorusMesh.new(), Vector3(0, -0.31, 0), Vector3(0.29, 0.29, 0.29), gold)
    _arm_left = Node3D.new(); _arm_left.position = Vector3(-0.42, 0.20, 0); _visual.add_child(_arm_left)
    _mesh(_arm_left, "ArmL", CapsuleMesh.new(), Vector3(-0.10, -0.22, 0), Vector3(0.20, 0.45, 0.20), skin)
    _mesh(_arm_left, "ArmBraceL", TorusMesh.new(), Vector3(-0.12, -0.34, 0), Vector3(0.13,0.13,0.13), gold)
    _arm_right = Node3D.new(); _arm_right.position = Vector3(0.42, 0.20, 0); _visual.add_child(_arm_right)
    _mesh(_arm_right, "ArmR", CapsuleMesh.new(), Vector3(0.10, -0.22, 0), Vector3(0.20, 0.45, 0.20), skin)
    _mesh(_arm_right, "ArmBraceR", TorusMesh.new(), Vector3(0.12, -0.34, 0), Vector3(0.13,0.13,0.13), gold)
    _leg_left = Node3D.new(); _leg_left.position = Vector3(-0.20,-0.48,0); _visual.add_child(_leg_left)
    _mesh(_leg_left, "LegL", CapsuleMesh.new(), Vector3(0,-0.23,0), Vector3(0.22,0.50,0.24), skin)
    _leg_right = Node3D.new(); _leg_right.position = Vector3(0.20,-0.48,0); _visual.add_child(_leg_right)
    _mesh(_leg_right, "LegR", CapsuleMesh.new(), Vector3(0,-0.23,0), Vector3(0.22,0.50,0.24), skin)
    # Decorative segmented tail: intentionally stylized proxy geometry, not final sculpt.
    for i in range(7):
        var t := float(i) / 6.0
        _mesh(_visual, "TailSegment_%02d" % i, SphereMesh.new(), Vector3(-0.12 - 0.1 * sin(t * PI), -0.12 + t * 0.85, 0.32 + t * 0.35), Vector3(0.10 - t * 0.025,0.10 - t * 0.025,0.10 - t * 0.025), skin)
    # Gada grip and head at the character's side.
    _mesh(_visual, "GadaHandle", CylinderMesh.new(), Vector3(0.68, -0.03, -0.10), Vector3(0.075, 0.72, 0.075), gold)
    _mesh(_visual, "GadaHead", SphereMesh.new(), Vector3(0.68, -0.42, -0.10), Vector3(0.23,0.26,0.23), gold)

func _create_camera() -> void:
    # Fixed trailing camera is deliberately simple and reliable for the first mobile slice.
    # Positive local Z places it behind a hero who faces -Z; the negative pitch looks down.
    var camera := Camera3D.new()
    camera.name = "PlayerCamera"
    camera.position = Vector3(0.0, 2.75, 6.2)
    camera.rotation.x = deg_to_rad(-12.0)
    camera.current = true
    camera.fov = 68.0
    add_child(camera)

func _physics_process(delta: float) -> void:
    if _dead:
        return
    _attack_cooldown = maxf(0.0, _attack_cooldown - delta)
    _pulse_cooldown = maxf(0.0, _pulse_cooldown - delta)
    _dodge_time = maxf(0.0, _dodge_time - delta)
    _invulnerability = maxf(0.0, _invulnerability - delta)
    _anim_clock += delta
    var keyboard := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
    var move_input := touch_move_vector if touch_move_vector.length() > 0.12 else keyboard
    var camera := get_viewport().get_camera_3d()
    var direction := Vector3.ZERO
    if move_input.length() > 0.05:
        if camera != null:
            var forward := -camera.global_basis.z
            var right := camera.global_basis.x
            forward.y = 0.0
            right.y = 0.0
            direction = (right.normalized() * move_input.x + forward.normalized() * -move_input.y).normalized()
        else:
            direction = Vector3(move_input.x, 0.0, -move_input.y).normalized()
    if not is_on_floor():
        velocity.y -= float(ProjectSettings.get_setting("physics/3d/default_gravity")) * delta
    elif Input.is_action_just_pressed("jump"):
        velocity.y = 4.5
    var speed := dodge_speed if _dodge_time > 0.0 else move_speed
    velocity.x = direction.x * speed
    velocity.z = direction.z * speed
    move_and_slide()
    if direction.length_squared() > 0.03:
        _visual.rotation.y = lerp_angle(_visual.rotation.y, atan2(-direction.x, -direction.z), delta * 9.0)
    _visual.position.y = 0.92 + sin(_anim_clock * 8.0) * 0.018
    if _dodge_time > 0.0:
        _visual.scale = Vector3(0.92, 0.94, 0.92)
    else:
        _visual.scale = Vector3.ONE
    if Input.is_action_just_pressed("attack"):
        try_attack()
    if Input.is_action_just_pressed("divine_pulse"):
        try_divine_pulse()
    if Input.is_action_just_pressed("dodge"):
        try_dodge()

func set_touch_move_vector(value: Vector2) -> void:
    touch_move_vector = value.limit_length(1.0)

func try_attack() -> void:
    if _attack_cooldown > 0.0 or _dead:
        return
    _attack_cooldown = 0.48
    if _arm_right != null:
        var tween := create_tween()
        tween.tween_property(_arm_right, "rotation:x", -1.0, 0.09)
        tween.tween_property(_arm_right, "rotation:x", 0.0, 0.20)
    var nearest: Node3D = null
    var nearest_dist := 3.0
    var facing := -_visual.global_basis.z
    for enemy in get_tree().get_nodes_in_group("enemies"):
        if not is_instance_valid(enemy) or not enemy.has_method("take_damage"):
            continue
        var offset: Vector3 = enemy.global_position - global_position
        var distance := Vector2(offset.x, offset.z).length()
        var toward := Vector3(offset.x, 0.0, offset.z).normalized()
        if distance < nearest_dist and (facing.dot(toward) > -0.05):
            nearest = enemy
            nearest_dist = distance
    if nearest != null:
        nearest.take_damage(26.0)
        if world_controller != null and world_controller.has_method("spawn_hit_spark"):
            world_controller.call("spawn_hit_spark", nearest.global_position + Vector3(0,1,0))

func try_divine_pulse() -> void:
    if _pulse_cooldown > 0.0 or _dead:
        return
    _pulse_cooldown = 4.0
    if world_controller != null and world_controller.has_method("spawn_divine_pulse"):
        world_controller.call("spawn_divine_pulse", global_position + Vector3(0,0.08,0))
    for enemy in get_tree().get_nodes_in_group("enemies"):
        if is_instance_valid(enemy) and enemy.has_method("take_damage"):
            var offset: Vector3 = enemy.global_position - global_position
            if Vector2(offset.x, offset.z).length() <= 5.2:
                enemy.take_damage(42.0)

func try_dodge() -> void:
    if _dead:
        return
    _dodge_time = 0.22
    _invulnerability = 0.35

func apply_damage(amount: float) -> void:
    if _dead or _invulnerability > 0.0:
        return
    health = maxf(0.0, health - amount)
    health_changed.emit(health, max_health)
    if health <= 0.0:
        _dead = true
        defeated.emit()

func reset_player() -> void:
    _dead = false
    health = max_health
    velocity = Vector3.ZERO
    health_changed.emit(health, max_health)

func _material(color: Color, metallic: float = 0.0, roughness: float = 0.7, emission: Color = Color.BLACK, energy: float = 0.0) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.metallic = metallic
    m.roughness = roughness
    if energy > 0.0:
        m.emission_enabled = true
        m.emission = emission
        m.emission_energy_multiplier = energy
    return m

func _mesh(parent: Node3D, node_name: String, mesh: Mesh, pos: Vector3, scale_value: Vector3, mat: Material) -> MeshInstance3D:
    var instance := MeshInstance3D.new()
    instance.name = node_name
    instance.mesh = mesh
    instance.position = pos
    instance.scale = scale_value
    instance.material_override = mat
    parent.add_child(instance)
    return instance
