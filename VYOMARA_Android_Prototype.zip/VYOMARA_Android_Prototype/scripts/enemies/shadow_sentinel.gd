extends CharacterBody3D
## Original fictional gameplay enemy. Not a figure from scripture or a traditional deity.
signal defeated
signal health_changed(current: float, maximum: float)
signal attack_telegraph_started
@export var max_health: float = 160.0
@export var move_speed: float = 1.8
@export var attack_damage: float = 13.0
var health: float = 160.0
var target
var _attack_timer := 0.0
var _windup_timer := 0.0
var _winding_up := false
var _defeated := false
var _visual: Node3D
var _clock := 0.0

func _ready() -> void:
    add_to_group("enemies")
    health = max_health
    var shape := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.48
    capsule.height = 2.15
    shape.shape = capsule
    shape.position.y = 1.07
    add_child(shape)
    _create_visual()
    health_changed.emit(health, max_health)

func _create_visual() -> void:
    _visual = Node3D.new()
    _visual.position.y = 1.0
    add_child(_visual)
    var armor := _mat(Color(0.075,0.065,0.12),0.72,0.36)
    var edge := _mat(Color(0.32,0.22,0.47),0.62,0.42,Color(0.12,0.025,0.28),0.7)
    var ember := _mat(Color(1.0,0.25,0.06),0.1,0.25,Color(1.0,0.08,0.01),2.2)
    _mesh(_visual,"ArmorTorso",CapsuleMesh.new(),Vector3(0,0.0,0),Vector3(0.86,0.90,0.62),armor)
    _mesh(_visual,"Helm",SphereMesh.new(),Vector3(0,0.70,-0.02),Vector3(0.54,0.50,0.52),armor)
    _mesh(_visual,"HornLeft",ConeMesh.new(),Vector3(-0.33,1.05,0.02),Vector3(0.16,0.38,0.16),edge)
    _mesh(_visual,"HornRight",ConeMesh.new(),Vector3(0.33,1.05,0.02),Vector3(0.16,0.38,0.16),edge)
    _mesh(_visual,"EyeLeft",SphereMesh.new(),Vector3(-0.18,0.73,-0.47),Vector3(0.08,0.055,0.04),ember)
    _mesh(_visual,"EyeRight",SphereMesh.new(),Vector3(0.18,0.73,-0.47),Vector3(0.08,0.055,0.04),ember)
    _mesh(_visual,"ShoulderLeft",SphereMesh.new(),Vector3(-0.56,0.32,0),Vector3(0.32,0.27,0.32),edge)
    _mesh(_visual,"ShoulderRight",SphereMesh.new(),Vector3(0.56,0.32,0),Vector3(0.32,0.27,0.32),edge)
    _mesh(_visual,"Core",SphereMesh.new(),Vector3(0,-0.03,-0.34),Vector3(0.18,0.2,0.07),ember)
    _mesh(_visual,"WeaponShaft",CylinderMesh.new(),Vector3(0.73,0.0,0),Vector3(0.08,0.95,0.08),edge)
    _mesh(_visual,"WeaponHead",SphereMesh.new(),Vector3(0.73,-0.53,0),Vector3(0.22,0.25,0.22),edge)

func _physics_process(delta: float) -> void:
    if _defeated:
        return
    _clock += delta
    _attack_timer = maxf(0.0, _attack_timer-delta)
    if not is_instance_valid(target):
        var players := get_tree().get_nodes_in_group("player")
        if players.size() > 0:
            target = players[0] as CharacterBody3D
    if not is_instance_valid(target):
        return
    var offset: Vector3 = target.global_position-global_position
    var flat := Vector3(offset.x,0,offset.z)
    var distance := flat.length()
    if distance > 2.1:
        var dir := flat.normalized()
        velocity.x = dir.x * move_speed
        velocity.z = dir.z * move_speed
        _visual.rotation.y = lerp_angle(_visual.rotation.y, atan2(-dir.x,-dir.z),delta*5.0)
        _winding_up = false
        _windup_timer = 0.0
        _visual.scale = Vector3.ONE
    else:
        velocity.x = move_toward(velocity.x,0.0,move_speed*4.0*delta)
        velocity.z = move_toward(velocity.z,0.0,move_speed*4.0*delta)
        if _attack_timer <= 0.0:
            if not _winding_up:
                _windup_timer = 0.42
                _winding_up = true
                attack_telegraph_started.emit()
            else:
                _windup_timer -= delta
                _visual.scale = Vector3(1.08, 1.08, 1.08)
                if _windup_timer <= 0.0:
                    _winding_up = false
                    _attack_timer = 1.35
                    _visual.scale = Vector3.ONE
                    if target.has_method("apply_damage"):
                        target.call("apply_damage", attack_damage)
        else:
            _winding_up = false
            _windup_timer = 0.0
            _visual.scale = Vector3.ONE
    if not is_on_floor():
        velocity.y -= float(ProjectSettings.get_setting("physics/3d/default_gravity"))*delta
    move_and_slide()
    _visual.position.y = 1.0 + sin(_clock*2.6)*0.04

func take_damage(amount: float) -> void:
    if _defeated:
        return
    health = maxf(0.0,health-amount)
    health_changed.emit(health,max_health)
    if health <= 0.0:
        _defeated = true
        remove_from_group("enemies")
        defeated.emit()
        var tween := create_tween()
        tween.tween_property(_visual,"scale",Vector3(0.05,0.05,0.05),0.38)
        tween.tween_callback(queue_free)

func _mat(color: Color, metallic: float = 0.0, roughness: float = 0.7, emission: Color = Color.BLACK, energy: float = 0.0) -> StandardMaterial3D:
    var m := StandardMaterial3D.new(); m.albedo_color=color; m.metallic=metallic; m.roughness=roughness
    if energy>0.0:
        m.emission_enabled=true; m.emission=emission; m.emission_energy_multiplier=energy
    return m
func _mesh(parent: Node3D, node_name: String, mesh: Mesh, pos: Vector3, scale_value: Vector3, mat: Material) -> MeshInstance3D:
    var instance:=MeshInstance3D.new();instance.name=node_name;instance.mesh=mesh;instance.position=pos;instance.scale=scale_value;instance.material_override=mat;parent.add_child(instance);return instance
