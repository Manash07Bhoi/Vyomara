extends Node
## Minimal versioned offline save service. No network dependency.
const SAVE_PATH := "user://vyomara_save.cfg"
const SAVE_VERSION := 1

func save_completion(completed: bool) -> bool:
    var cfg := ConfigFile.new()
    cfg.set_value("meta", "version", SAVE_VERSION)
    cfg.set_value("progress", "first_light_completed", completed)
    cfg.set_value("meta", "saved_unix_time", Time.get_unix_time_from_system())
    return cfg.save(SAVE_PATH) == OK

func load_progress() -> Dictionary:
    var cfg := ConfigFile.new()
    var err := cfg.load(SAVE_PATH)
    if err != OK:
        return {"first_light_completed": false, "save_exists": false}
    var version := int(cfg.get_value("meta", "version", 0))
    if version != SAVE_VERSION:
        return {"first_light_completed": false, "save_exists": true, "version_mismatch": true}
    return {
        "first_light_completed": bool(cfg.get_value("progress", "first_light_completed", false)),
        "save_exists": true,
        "version_mismatch": false
    }
