extends Node3D
## Procedural, low-poly first-realm set. Replace/augment with licensed GLB assets incrementally.
var shrine: Node3D
var gateway: Node3D
var sentinel_spawn := Vector3(0, 0.20, -3.5)
var _materials: Dictionary = {}

func build_world() -> void:
    _build_environment()
    var stone := _mat("warm sandstone",Color(0.43,0.31,0.22),0.08,0.86)
    var pale_stone := _mat("temple stone",Color(0.64,0.48,0.31),0.12,0.72)
    var dark_stone := _mat("dark stone",Color(0.12,0.15,0.20),0.15,0.83)
    var gold := _mat("aged gold",Color(0.88,0.62,0.21),0.62,0.35,Color(0.38,0.17,0.025),0.35)
    var blue := _mat("deep water",Color(0.045,0.21,0.36),0.34,0.2,Color(0.01,0.07,0.18),0.3)
    var leaf := _mat("sacred grove",Color(0.08,0.26,0.18),0.0,0.9)
    var leaf_light := _mat("grove highlight",Color(0.18,0.39,0.24),0.0,0.88)
    var warm_light := _mat("lamp glow",Color(1.0,0.67,0.19),0.0,0.3,Color(1.0,0.31,0.035),2.4)
    var crystal := _mat("celestial crystal",Color(0.13,0.65,0.88),0.1,0.2,Color(0.03,0.44,1.0),1.8)

    # Broad playable ground with a continuous collider; all progress remains local/offline.
    _box(self,"WorldGround",Vector3(150,1.0,150),Vector3(0,-0.52,0),dark_stone,true)
    _box(self,"ProcessionalCourt",Vector3(38,0.22,44),Vector3(0,0.09,0),stone,true)
    _box(self,"CourtInset",Vector3(24,0.03,35),Vector3(0,0.215,0),pale_stone,false)
    for z in range(-16,18,4):
        _box(self,"CourtInlay_%d"%z,Vector3(0.12,0.025,2.6),Vector3(0,0.245,float(z)),gold,false)
    # Outer water basins add layered colour and a sense of height around the court.
    _box(self,"WestWater",Vector3(18,0.18,48),Vector3(-27,-0.02,-2),blue,false)
    _box(self,"EastWater",Vector3(18,0.18,48),Vector3(27,-0.02,-2),blue,false)
    # Temple stairs are art geometry; the flat continuous ground avoids frustrating tiny collision steps.
    for i in range(7):
        var step_z := -8.0-float(i)*1.15
        var step_y := 0.22+float(i)*0.035
        _box(self,"TempleStep_%02d"%i,Vector3(12.0,0.18,1.28),Vector3(0,step_y,step_z),pale_stone,false)
    _build_temple(pale_stone,stone,gold,dark_stone,warm_light)
    _build_columns(stone,pale_stone,gold)
    _build_gardens(leaf,leaf_light,stone)
    _build_backdrop(dark_stone,stone,gold,blue,crystal)
    _build_lamps(warm_light,gold)
    _build_shrine(gold,crystal,pale_stone)
    _build_gateway(gold,crystal,dark_stone)

func _build_environment() -> void:
    var world_env := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color(0.018,0.045,0.13)
    sky_mat.sky_horizon_color = Color(0.78,0.42,0.22)
    sky_mat.ground_bottom_color = Color(0.045,0.055,0.08)
    sky_mat.ground_horizon_color = Color(0.25,0.18,0.18)
    sky_mat.sun_angle_max = 22.0
    sky.sky_material = sky_mat
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.ambient_light_energy = 0.72
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.fog_enabled = true
    env.fog_light_color = Color(0.56,0.48,0.49)
    env.fog_density = 0.0045
    world_env.environment = env
    add_child(world_env)
    var sun := DirectionalLight3D.new()
    sun.name = "GoldenHourSun"
    sun.rotation = Vector3(deg_to_rad(-49.0),deg_to_rad(-30.0),deg_to_rad(-5.0))
    sun.light_color = Color(1.0,0.78,0.54)
    sun.light_energy = 1.18
    sun.shadow_enabled = true
    add_child(sun)
    var fill := DirectionalLight3D.new()
    fill.name = "SkyFill"
    fill.rotation = Vector3(deg_to_rad(-24.0),deg_to_rad(145.0),0.0)
    fill.light_color = Color(0.25,0.48,0.92)
    fill.light_energy = 0.28
    add_child(fill)

func _build_temple(stone: Material,pale: Material,gold: Material,dark: Material,glow: Material) -> void:
    _box(self,"TempleFoundation",Vector3(21,0.18,13),Vector3(0,0.09,-20.0),stone,false)
    _box(self,"SanctumFrontWallLeft",Vector3(3.35,4.4,1.2),Vector3(-3.33,2.5,-23.5),pale,true)
    _box(self,"SanctumFrontWallRight",Vector3(3.35,4.4,1.2),Vector3(3.33,2.5,-23.5),pale,true)
    _box(self,"SanctumLeftWall",Vector3(1.2,4.4,7.0),Vector3(-4.8,2.5,-20.0),pale,true)
    _box(self,"SanctumRightWall",Vector3(1.2,4.4,7.0),Vector3(4.8,2.5,-20.0),pale,true)
    _box(self,"SanctumTopBeam",Vector3(11,0.7,8.0),Vector3(0,4.65,-20.0),gold,false)
    # Dravidian-inspired tiered silhouette: original fictional structure, not a replica of a sacred site.
    for i in range(5):
        var h := 0.52
        var width := 7.8-float(i)*1.18
        var depth := 5.0-float(i)*0.72
        _box(self,"VimanaTier_%02d"%i,Vector3(width,h,depth),Vector3(0,5.05+float(i)*0.48,-20.0),stone if i%2==0 else pale,false)
        _box(self,"VimanaGoldLine_%02d"%i,Vector3(width+0.12,0.065,depth+0.12),Vector3(0,5.05+float(i)*0.48+h*0.5,-20.0),gold,false)
    _cylinder(self,"TempleFinial",1.9,0.05,0.32,Vector3(0,8.2,-20),gold,false)
    _sphere(self,"TempleCrownGem",0.25,Vector3(0,9.25,-20),glow,false)
    for x in [-3.6,-1.2,1.2,3.6]:
        _cylinder(self,"FrontPillar_%s"%str(x),3.5,0.24,0.32,Vector3(x,2.0,-24.0),stone,true)
        _cylinder(self,"FrontPillarCap_%s"%str(x),0.24,0.42,0.42,Vector3(x,3.83,-24.0),gold,false)
    _box(self,"TempleLintel",Vector3(10.0,0.42,0.72),Vector3(0,4.05,-24.0),gold,false)
    _box(self,"TempleBannerPole",Vector3(0.10,5.4,0.10),Vector3(-6.3,2.8,-19.0),gold,false)
    _box(self,"TempleBanner",Vector3(1.15,2.25,0.10),Vector3(-6.3,4.1,-19.0),_mat("saffron banner",Color(0.65,0.12,0.04)),false)
    _sphere(self,"BannerSigil",0.22,Vector3(-6.3,4.4,-18.92),gold,false)

func _build_columns(stone: Material,pale: Material,gold: Material) -> void:
    for side in [-1.0,1.0]:
        for i in range(6):
            var z := -17.0+float(i)*5.2
            var x := side*9.3
            _cylinder(self,"Col_%s_%02d"%[str(side),i],3.5,0.23,0.32,Vector3(x,1.75,z),pale,true)
            _cylinder(self,"ColBase_%s_%02d"%[str(side),i],0.28,0.48,0.48,Vector3(x,0.18,z),stone,false)
            _cylinder(self,"ColCap_%s_%02d"%[str(side),i],0.27,0.42,0.42,Vector3(x,3.52,z),gold,false)
        for i in range(3):
            var z := -16.0+float(i)*7.0
            _box(self,"OuterLintel_%s_%d"%[str(side),i],Vector3(2.6,0.26,0.55),Vector3(side*9.3,3.75,z),stone,false)

func _build_gardens(leaf: Material,leaf_light: Material,stone: Material) -> void:
    for side in [-1.0,1.0]:
        for i in range(8):
            var z := -21.0+float(i)*5.5
            var x := side*(14.0+float(i%2)*1.4)
            _cylinder(self,"TreeTrunk_%s_%d"%[str(side),i],1.8,0.18,0.28,Vector3(x,0.85,z),stone,false)
            _cylinder(self,"TreeCrownA_%s_%d"%[str(side),i],2.8,0.0,1.65,Vector3(x,2.75,z),leaf,false)
            _cylinder(self,"TreeCrownB_%s_%d"%[str(side),i],2.0,0.0,1.15,Vector3(x,3.6,z),leaf_light,false)
            if i%2==0:
                _sphere(self,"GroveGlow_%s_%d"%[str(side),i],0.12,Vector3(x+0.6,2.6,z-0.4),_mat("firefly",Color(0.55,0.9,0.98),0.0,0.25,Color(0.1,0.65,1),1.4),false)

func _build_backdrop(dark: Material,stone: Material,gold: Material,water: Material,crystal: Material) -> void:
    # Distant polygonal mountain line.
    for i in range(21):
        var x := -52.0+float(i)*5.2
        var height := 10.0+float((i*7)%9)*1.3
        var z := -43.0-float((i*3)%7)*1.2
        _cylinder(self,"DistantMountain_%02d"%i,height,0.0,5.0+float(i%3),Vector3(x,height*0.48,z),dark if i%2==0 else stone,false)
        _cylinder(self,"SnowTip_%02d"%i,height*0.22,0.0,1.2,Vector3(x,height*0.93,z),_mat("snowcap",Color(0.62,0.73,0.83),0,0.92),false)
    # Floating rock islands and small temple-like silhouettes along the skyline.
    for i in range(7):
        var side := -1.0 if i%2==0 else 1.0
        var x := side*(23.0+float(i%3)*8.0)
        var y := 12.0+float(i%4)*2.2
        var z := -34.0-float(i%3)*4.5
        _sphere(self,"FloatingIslandTop_%d"%i,2.5,Vector3(x,y,z),stone,false)
        _cylinder(self,"FloatingIslandRock_%d"%i,4.0,0.4,2.5,Vector3(x,y-2.5,z),dark,false)
        _cylinder(self,"FloatingShrine_%d"%i,2.7,0.65,1.35,Vector3(x,y+2.0,z),gold if i%2==0 else stone,false)
        _sphere(self,"IslandBeacon_%d"%i,0.16,Vector3(x,y+3.6,z),crystal,false)
    # Waterfall ribbons visible in the middle distance.
    for i in range(5):
        var x := -24.0+float(i)*12.0
        var z := -38.0-float(i%2)*2.0
        var sheet := _mat("waterfall translucent",Color(0.26,0.61,0.84,0.72),0.2,0.22,Color(0.04,0.28,0.6),0.4)
        sheet.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        _box(self,"Waterfall_%d"%i,Vector3(1.45,8.0,0.10),Vector3(x,2.8,z),sheet,false)

func _build_lamps(glow: Material,gold: Material) -> void:
    for x in [-15.0,-8.0,8.0,15.0]:
        for z in [-19.0,-8.0,2.0,12.0]:
            _cylinder(self,"LampPedestal_%s_%s"%[str(x),str(z)],0.65,0.24,0.34,Vector3(x,0.32,z),gold,false)
            _sphere(self,"LampFlame_%s_%s"%[str(x),str(z)],0.16,Vector3(x,0.78,z),glow,false)
            if abs(x) < 10.0:
                var light := OmniLight3D.new()
                light.position = Vector3(x,1.0,z)
                light.light_color = Color(1.0,0.48,0.12)
                light.light_energy = 0.3
                light.omni_range = 4.0
                add_child(light)

func _build_shrine(gold: Material,crystal: Material,stone: Material) -> void:
    shrine = Node3D.new()
    shrine.name = "DharmaShrine_INTERACT_AFTER_SENTINEL"
    shrine.position = Vector3(0,0,-19.3)
    add_child(shrine)
    _cylinder(shrine,"ShrineBase",0.5,1.25,1.4,Vector3(0,0.25,0),stone,false)
    _cylinder(shrine,"ShrineRing",0.15,1.0,1.0,Vector3(0,0.58,0),gold,false)
    _sphere(shrine,"ShrineCore",0.62,Vector3(0,1.26,0),crystal,false)
    for i in range(8):
        var a := TAU*float(i)/8.0
        var pos := Vector3(cos(a)*0.95,1.15,sin(a)*0.95)
        _sphere(shrine,"ShrineOrbit_%02d"%i,0.1,pos,gold,false)

func _build_gateway(gold: Material,crystal: Material,dark: Material) -> void:
    gateway = Node3D.new()
    gateway.name = "CelestialGateway"
    gateway.position = Vector3(0,0,-29.0)
    add_child(gateway)
    _cylinder(gateway,"GatePostL",5.8,0.27,0.42,Vector3(-3.1,2.9,0),gold,true)
    _cylinder(gateway,"GatePostR",5.8,0.27,0.42,Vector3(3.1,2.9,0),gold,true)
    _box(gateway,"GateTop",Vector3(6.8,0.42,0.6),Vector3(0,5.8,0),gold,false)
    _sphere(gateway,"GateHeart",0.58,Vector3(0,5.8,-0.1),crystal,false)
    _box(gateway,"GateSeal",Vector3(4.4,4.7,0.14),Vector3(0,2.55,-0.04),dark,false)
    _box(gateway,"GateInnerLight",Vector3(3.7,3.9,0.08),Vector3(0,2.55,-0.12),crystal,false)

func _box(parent: Node3D,node_name: String,size: Vector3,pos: Vector3,mat: Material,collider: bool=false) -> Node3D:
    var root: Node3D
    if collider:
        var body := StaticBody3D.new();body.name=node_name;body.position=pos;parent.add_child(body);root=body
        var shape := CollisionShape3D.new();var box_shape:=BoxShape3D.new();box_shape.size=size;shape.shape=box_shape;body.add_child(shape)
    else:
        root=MeshInstance3D.new();root.name=node_name;root.position=pos;parent.add_child(root)
    var mesh_instance: MeshInstance3D
    if collider:
        mesh_instance=MeshInstance3D.new();root.add_child(mesh_instance)
    else:
        mesh_instance=root as MeshInstance3D
    var mesh := BoxMesh.new();mesh.size=size;mesh_instance.mesh=mesh;mesh_instance.material_override=mat
    return root

func _cylinder(parent: Node3D,node_name: String,height: float,top_radius: float,bottom_radius: float,pos: Vector3,mat: Material,collider: bool=false) -> Node3D:
    var mesh := CylinderMesh.new();mesh.height=height;mesh.top_radius=top_radius;mesh.bottom_radius=bottom_radius;mesh.radial_segments=10
    var inst := MeshInstance3D.new();inst.name=node_name;inst.position=pos;inst.mesh=mesh;inst.material_override=mat;parent.add_child(inst)
    if collider:
        var body:=StaticBody3D.new();body.name=node_name+"_Collider";body.position=pos;parent.add_child(body)
        var shape:=CollisionShape3D.new();var cylinder:=CylinderShape3D.new();cylinder.height=height;cylinder.radius=maxf(top_radius,bottom_radius);shape.shape=cylinder;body.add_child(shape)
    return inst

func _sphere(parent: Node3D,node_name: String,radius: float,pos: Vector3,mat: Material,collider: bool=false) -> Node3D:
    var mesh:=SphereMesh.new();mesh.radius=radius;mesh.height=radius*2.0;mesh.radial_segments=12;mesh.rings=6
    var inst:=MeshInstance3D.new();inst.name=node_name;inst.position=pos;inst.mesh=mesh;inst.material_override=mat;parent.add_child(inst)
    if collider:
        var body:=StaticBody3D.new();body.position=pos;parent.add_child(body);var shape:=CollisionShape3D.new();var sphere_shape:=SphereShape3D.new();sphere_shape.radius=radius;shape.shape=sphere_shape;body.add_child(shape)
    return inst

func _mat(key: String,color: Color,metallic: float=0.0,roughness: float=0.8,emission: Color=Color.BLACK,energy: float=0.0) -> StandardMaterial3D:
    if _materials.has(key):
        return _materials[key] as StandardMaterial3D
    var m:=StandardMaterial3D.new();m.resource_name=key;m.albedo_color=color;m.metallic=metallic;m.roughness=roughness
    if energy>0.0:
        m.emission_enabled=true;m.emission=emission;m.emission_energy_multiplier=energy
    _materials[key]=m
    return m
