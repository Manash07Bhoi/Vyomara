extends Node3D

const HERO_SCENE := "res://scenes/player/Hero.tscn"
const ENEMY_SCENE := "res://scenes/enemies/ShadowSentinel.tscn"
const WORLD_BUILDER := preload("res://scripts/world/world_builder.gd")
const SCORE := "res://assets/music/vyomara_original_synthetic_score.ogg"
const BELL := preload("res://assets/sfx/temple_bell_synthetic.wav")
const PULSE_SFX := preload("res://assets/sfx/divine_pulse_synthetic.wav")
const IMPACT_SFX := preload("res://assets/sfx/stone_impact_synthetic.wav")

var hero
var sentinel
var builder
var hud: CanvasLayer
var shrine_activated := false
var mission_complete := false
var _music: AudioStreamPlayer

func _ready() -> void:
    _setup_world()
    _spawn_hero()
    _spawn_enemy()
    _setup_hud()
    _setup_audio()
    var saved := SaveService.load_progress()
    if bool(saved.get("first_light_completed",false)):
        hud.call("notify", "Welcome back. The realm is ready to replay.")
    else:
        hud.call("show_intro")

func _setup_world() -> void:
    builder = WORLD_BUILDER.new()
    builder.name = "FirstRealm_ProceduralSet"
    add_child(builder)
    builder.build_world()

func _spawn_hero() -> void:
    hero = load(HERO_SCENE).instantiate() as CharacterBody3D
    hero.name = "Hanuman_Proxy_DO_NOT_SHIP_AS_FINAL_ART"
    hero.position = Vector3(0,0.20,12.0)
    hero.world_controller = self
    hero.health_changed.connect(_on_player_health_changed)
    hero.defeated.connect(show_failure)
    add_child(hero)

func _spawn_enemy() -> void:
    sentinel = load(ENEMY_SCENE).instantiate() as CharacterBody3D
    sentinel.name = "ShadowSentinel_OriginalFictionalEnemy"
    sentinel.position = builder.sentinel_spawn
    sentinel.target = hero
    sentinel.defeated.connect(_on_sentinel_defeated)
    sentinel.attack_telegraph_started.connect(_on_sentinel_telegraph)
    sentinel.health_changed.connect(_on_enemy_health_changed)
    add_child(sentinel)

func _setup_hud() -> void:
    var hud_script = load("res://scripts/ui/touch_hud.gd")
    hud = CanvasLayer.new()
    hud.name = "TouchHUD"
    hud.set_script(hud_script)
    add_child(hud)
    hud.call("bind",hero,self)
    hud.call("set_objective","Defeat the Shadow Sentinel")
    hud.call("set_health",hero.health,hero.max_health)

func _setup_audio() -> void:
    _music = AudioStreamPlayer.new()
    _music.stream = load(SCORE)
    _music.volume_db = -16.0
    add_child(_music)
    _music.finished.connect(func(): _music.play())
    _music.play()

func _on_player_health_changed(current: float, maximum: float) -> void:
    if is_instance_valid(hud):
        hud.call("set_health",current,maximum)

func _on_enemy_health_changed(current: float, maximum: float) -> void:
    if is_instance_valid(hud):
        hud.call("set_enemy_health",current,maximum)

func _on_sentinel_telegraph() -> void:
    if is_instance_valid(hud):
        hud.call("notify", "The guardian winds up — DODGE now!")

func _on_sentinel_defeated() -> void:
    if is_instance_valid(hud):
        hud.call("set_enemy_health",0.0,160.0)
        hud.call("set_objective","Reach the Dharma Shrine and interact")
        hud.call("notify","The guardian fades. The shrine is unsealed.")
    _play_sfx(IMPACT_SFX,-2.0)

func try_interact() -> void:
    if mission_complete:
        if is_instance_valid(hud): hud.call("notify","The First Light is complete. Replay from the menu.")
        return
    var shrine: Node3D = builder.shrine
    var distance := Vector2(shrine.global_position.x-hero.global_position.x,shrine.global_position.z-hero.global_position.z).length()
    if distance > 3.5:
        if is_instance_valid(hud): hud.call("notify","Move closer to the shrine.")
        return
    if is_instance_valid(sentinel) and sentinel.is_inside_tree() and sentinel.is_in_group("enemies"):
        if is_instance_valid(hud): hud.call("notify","The guardian still protects the shrine.")
        return
    shrine_activated = true
    mission_complete = true
    builder.gateway.get_node_or_null("GateSeal").visible = false
    builder.gateway.get_node_or_null("GateInnerLight").visible = true
    _play_sfx(BELL,0.0)
    SaveService.save_completion(true)
    if is_instance_valid(hud):
        hud.call("set_objective","FIRST LIGHT RESTORED")
        hud.call("show_victory")
    spawn_divine_pulse(shrine.global_position+Vector3(0,0.2,0),true)

func spawn_divine_pulse(position_value: Vector3,large: bool=false) -> void:
    _play_sfx(PULSE_SFX,-4.0)
    var ring := MeshInstance3D.new()
    var disk := CylinderMesh.new();disk.height=0.035;disk.top_radius=0.9;disk.bottom_radius=0.9;disk.radial_segments=48
    ring.mesh=disk
    var mat:=StandardMaterial3D.new();mat.albedo_color=Color(1.0,0.66,0.19,0.40);mat.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA;mat.emission_enabled=true;mat.emission=Color(1.0,0.35,0.05);mat.emission_energy_multiplier=1.4;mat.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
    ring.material_override=mat
    ring.position=position_value
    add_child(ring)
    var end_size := 7.0 if large else 5.4
    var tween:=create_tween().set_parallel(true)
    tween.tween_property(ring,"scale",Vector3(end_size,1.0,end_size),0.48)
    tween.tween_property(mat,"albedo_color:a",0.0,0.48)
    tween.chain().tween_callback(ring.queue_free)

func spawn_hit_spark(position_value: Vector3) -> void:
    var spark:=MeshInstance3D.new();var mesh:=SphereMesh.new();mesh.radius=0.18;mesh.height=0.36;spark.mesh=mesh;spark.position=position_value
    var mat:=StandardMaterial3D.new();mat.albedo_color=Color(1.0,0.7,0.28);mat.emission_enabled=true;mat.emission=Color(1.0,0.3,0.04);mat.emission_energy_multiplier=2.0;spark.material_override=mat;add_child(spark)
    var tween:=create_tween().set_parallel(true);tween.tween_property(spark,"scale",Vector3(2.0,2.0,2.0),0.18);tween.tween_property(mat,"albedo_color:a",0.0,0.22);tween.chain().tween_callback(spark.queue_free)

func show_failure() -> void:
    if is_instance_valid(hud): hud.call("show_failure")

func restart_level() -> void:
    get_tree().reload_current_scene()

func return_to_menu() -> void:
    get_tree().change_scene_to_file("res://scenes/menu/MainMenu.tscn")

func _play_sfx(stream: AudioStream, volume_db: float=-4.0) -> void:
    var player:=AudioStreamPlayer.new();player.stream=stream;player.volume_db=volume_db;add_child(player);player.finished.connect(player.queue_free);player.play()
