# Third-Party Asset Credits

**No third-party asset binaries are included in the starter ZIP at this time**, so there are no third-party model/audio credits to claim as used. The external links documented in `ASSET_RESEARCH.md` are candidates only. They must not be described as bundled assets.

When the Arena agent successfully acquires an asset, add:

- Asset title:
- Creator:
- Source page URL:
- Exact license and version:
- Date accessed/downloaded:
- Required attribution text:
- File(s) used in project:
- Modifications / decimation / texture compression / rig changes:
- Scene(s) or usage:
- License text retained at:

Do not copy assets into this credit list as “used” until the file is actually present in the project and license has been checked.
