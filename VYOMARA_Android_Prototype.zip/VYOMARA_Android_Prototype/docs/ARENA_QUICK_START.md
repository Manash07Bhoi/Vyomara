# Arena Agent Mode — Quick Start

Arena's official help page: https://help.arena.ai/articles/5432423882-how-to-use-agent-mode

1. Open https://arena.ai/agent and switch to **Agent Mode**.
2. Start a fresh task. Paste the complete `ARENA_AGENT_MASTER_PROMPT.md` (or attach it as Markdown and enter “Follow the attached master prompt exactly; implement, test and package the project”).
3. Attach `VYOMARA_PRD.md`, `docs/ASSET_LEDGER.md`, `docs/MYTHOLOGY_AND_CULTURAL_GUARDRAILS.md`, `docs/QA_TEST_PLAN.md`, and the reference images in `assets/reference_art/` if upload is supported. These images are concept references only.
4. If Arena lets you connect GitHub and you have created a repo containing the project, connect it; review every diff/commit before merging. If no repository is connected, Arena's own workspace is designed to return a downloadable ZIP, according to the help page.
5. Ask it to continue all workstreams through testing and ZIP packaging; do not accept only a plan or prompt rewrite.
6. Require a final status table: implemented, downloaded/verified assets, passed tests, failed tests, untested items, blockers. Ask it to give raw Godot parse/test output when claimed.
7. Download the final ZIP from Arena's Workspace panel if no GitHub repository is connected. Keep that final ZIP separate from this starter until you've compared and reviewed it.

**Important:** Arena's published input-format list does not currently include ZIP, so it may not accept this entire starter ZIP as a project input in every workflow. Markdown and image uploads are listed; GitHub-connected repo work is the most reliable route for evolving the existing project. If ZIP upload is unavailable, use the master prompt to rebuild in Arena's workspace from the brief and attached Markdown/reference files, or first place these project files in a GitHub repo using your available tools.
