# VYOMARA First-Realm QA Plan

## Static/pre-import checks
- `project.godot` exists at project root.
- Main scene path resolves to `scenes/menu/MainMenu.tscn`.
- All referenced scripts/assets exist.
- No external plugin, API key, backend, login or network request is required.
- Asset ledger matches files actually shipped.

## Godot editor smoke test (required; not run in the file-authoring container)
1. Extract `VYOMARA_Android_Prototype.zip` to a local folder, not inside the ZIP viewer.
2. In Godot Android editor, choose **Import** / **Scan** and select that folder's `project.godot`.
3. Wait for texture/audio import. Resolve any parse errors before running; record Godot version and error text.
4. Run the main scene. Verify background, VYOMARA title, tagline, “A VISION BY JP” and enter button.
5. Enter the realm; verify 3D temple/court, sky, hero proxy, sentinel, HUD and touch joystick/buttons.
6. Move around the court and confirm floor collision and camera follow.
7. Use attack/GADA within reach; sentinel health decreases. Divine PULSE affects sentinel at range. Sentinel attacks the player within range.
8. Defeat sentinel; approach shrine and press ACT; victory overlay appears and save is written.
9. Restart level; verify the scene starts again. Return to title.
10. Enable airplane mode and repeat the core mission. No network should be required.
11. Test 10 minutes for thermal/performance, check for missing imports, UI clipping, black textures or crash.

## Performance target (initial)
- Compatibility renderer.
- 30 FPS goal on the actual device; no promise until measured.
- One real-time shadow-casting directional light; emissive materials instead of many dynamic point lights.
- Small bounded scene, no open-world streaming, no online dependencies.

## Current honesty statement
This starter was generated without a Godot executable in the authoring container. It has not been opened or runtime-tested by Godot here. The Android-editor smoke test is a required next step; do not describe the project as verified, production-ready, or a finished APK before running it.
