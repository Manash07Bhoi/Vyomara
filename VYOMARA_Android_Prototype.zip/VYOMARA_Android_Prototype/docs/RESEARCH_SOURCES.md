# Research Sources (checked 2026-10-20)

## Godot / Android
- **Android editor** — Android editor can create, run and export 2D/3D projects; currently documented as early access; no C#/Mono support; Forward+ is not recommended due to severe performance issues; UX on phones is not optimized. https://docs.godotengine.org/en/4.6/tutorials/editor/using_the_android_editor.html
- **Renderers** — Compatibility is intended for lower-end mobile/desktop broad support; Mobile supports newer Vulkan-capable mobile/desktop hardware. Choose based on real device tests rather than RAM alone. https://docs.godotengine.org/en/4.6/tutorials/rendering/renderers.html
- **glTF/GLB** — Godot recommends glTF 2.0 for 3D scene interchange. https://docs.godotengine.org/en/stable/tutorials/assets_pipeline/importing_3d_scenes/available_formats.html
- **3D prototype patterns** — Official starter uses CharacterBody3D, move_and_slide(), collisions, animation and restart/game loop patterns. https://docs.godotengine.org/en/4.6/getting_started/first_3d_game/index.html
- **Export templates** — The export template build must match the editor version; exported Android APK depends on templates and settings. https://docs.godotengine.org/en/4.6/tutorials/export/exporting_projects.html

## Free asset sources / license risks
- **Poly Haven** — states all assets are CC0; no attribution required, although credit is welcome. https://polyhaven.com/license and https://polyhaven.com/models
- **Kenney Nature Kit** — 3D, 330 files, page lists CC0. https://kenney.nl/assets/nature-kit
- **Kenney Prototype Kit** — 3D, 145 files, page lists CC0. https://kenney.nl/assets/prototype-kit
- **Quaternius Asset License** — the current QAL summary permits personal/educational/commercial projects without attribution, but prohibits re-selling/redistributing assets as standalone assets. Check the current exact license bundled with selected pack. https://github.com/Quaternius/quaternius.github.io/blob/main/license.html
- **South Indian Temple Modular Kit** — rSquare page describes this as a school assignment inspired by references, not based on a real temple; 8.3k triangles; CC BY. Verify downloadable file and attribution. https://sketchfab.com/3d-models/south-indian-temple-modular-kit-25f0176668004faa98ec351e04e58920
- **Hanuman (Animated)** — NG Creations model listing reports 177.2k triangles, 88.6k vertices, CC BY, and AI-generated. Treat as a candidate to inspect, not automatically suitable. https://sketchfab.com/3d-models/hanumananimated-c5af66701ee940f69a6b68384a5ba725
- **Hanumanji** — bothe.h listing reports 27.6k triangles, CC BY, AI-generated and a toy-like stylized style; likely mobile-light but possible mismatch with premium cinematic art direction. https://sketchfab.com/3d-models/hanumanji-5605eca5dc8d467686cc0771685ef9c4
- **Mixamo** — free with an Adobe ID; character/animation use allowed in games per FAQ; auto-rigger and animation library target bipedal humanoids, and extra appendages/tails can fail. https://helpx.adobe.com/creative-cloud/faq/mixamo-faq.html
- **Mixkit SFX** — free sound-effects license permits use in games, videos/social posts, and commercial projects; do not redistribute an individual sound effect standalone or claim ownership. https://mixkit.co/free-sound-effects/ and https://mixkit.co/license/modal/sfxFree/

## AI-generated concept reference limitations
The five reference images in `assets/reference_art/` are original AI-generated concept assets created for this project context. They are not actual 3D models and are not guaranteed to match iconographic traditions. Use them for high-level mood/colour/composition only, then research and review deity appearances carefully.

## Research conclusion
There are useful free environment assets and some deity model candidates, but “free”, “popular”, “high likes” and “mobile-ready” are different properties. The actual downloadable file, license, rig, triangle count, textures, visual accuracy and fit must be inspected. The pack-generation environment in this conversation had no outbound DNS; consequently, no third-party 3D model pack is claimed to be downloaded into the current project. The Arena master prompt requires the agent to perform this network-enabled acquisition/integration stage and record exactly what succeeds.
