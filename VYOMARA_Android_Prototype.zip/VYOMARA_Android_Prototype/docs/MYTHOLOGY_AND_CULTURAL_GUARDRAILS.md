# Mythology & Cultural Guardrails

VYOMARA is a Hindu mythology-inspired game adaptation. The current prototype is a fictional gameplay vignette, not an assertion about canonical scripture.

1. **Creator credit:** “A VISION BY JP” refers to creator/developer Jaya Prakash Sahu, not an in-world hero.
2. **No unrelated personal characters:** do not add JP, Rimi, or other real/private persons as deity characters or protagonists unless explicitly requested later.
3. **Cohesive first chapter:** the playable proxy currently follows Hanuman as the visual direction because Hanuman appeared in the glimpse. Before public release, source-review the story, chapter framing, iconography, costume, gada, posture, and actions against a clearly named Ramayana tradition (e.g., Valmiki Ramayana or Ramcharitmanas); do not silently merge variant traditions.
4. **Respect deities:** never make a revered deity an enemy/boss, comic relief, loot piñata, or an object to be killed. Do not invent dialogue and present it as a quotation from scripture.
5. **Fictional gameplay:** “Shadow Sentinel,” the First Light shrine objective, the celestial gate, and the generic pulse effect are original game fiction, not claimed scriptural beings/events. Mark this distinction in docs and public materials.
6. **Avoid mislabeling:** do not call a generated or generic model a canonical deity depiction. Credit real-world model creators, distinguish AI concept art from imported art, and obtain qualified cultural review before public investor/marketing release.
7. **Asset standards:** no ripped television serial/film characters, logos, actor likenesses, film scores, or copyrighted game content.
8. **Visual respect:** sacred symbols and iconography should be intentionally placed; avoid distorted script/mantras, random sacred symbols as floor decoration, and inappropriate weapon/action pairings.

The first prototype is an exploration/combat mechanics proof, not a canonical retelling of a named episode. The story can be rewritten after the creator chooses the source tradition and review approach.
