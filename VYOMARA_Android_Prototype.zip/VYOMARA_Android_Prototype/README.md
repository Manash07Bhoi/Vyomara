# VYOMARA — The First Light (Android-First Godot Prototype)

**A VISION BY JP**  
**Tagline:** *Across the Yugas. Through the Realms. Guided by Dharma.*

This is a genuine, editable Godot 4.x project scaffold for the first VYOMARA 3D vertical slice. The project contains a procedural 3D temple-court environment, mobile touch UI, keyboard fallback, a playable procedural Hanuman visual proxy, one fictional Shadow Sentinel enemy, melee/pulse/dodge mechanics, a shrine objective, local save service, concept-art title menu, and original synthetic music/SFX.

> **Honest status:** The project files and scripts are created. The Godot executable was unavailable in the authoring environment, so the project has not been opened or run in Godot during packaging. The avatar is a clearly named low-poly proxy, not a final-quality deity model. Third-party 3D packs have not been downloaded into this ZIP. Use the included PRD and Arena prompt to conduct acquisition, implementation, and test passes.

## Import on Android

1. Download and extract `VYOMARA_Android_Prototype.zip` in your phone's Downloads or Documents folder. Keep the complete `VYOMARA_Android_Prototype` folder intact.
2. Open Godot Android Editor, grant its requested file permission, choose Import/Open/Scan and select the extracted folder containing `project.godot`.
3. Wait for asset import; then run the project. If there are script/parser errors, capture the first error with its file/line and provide it to the coding agent.
4. Use the touch joystick bottom-left and action buttons bottom-right. Keyboard fallback is WASD/arrows, J=GADA attack, K=pulse, E=interact, L=dodge.
5. Main loop: defeat the original fictional Shadow Sentinel → move close to shrine → ACT → victory/save. This is a mechanics prototype, not a canonical Hindu scripture event.

## Files

- `VYOMARA_PRD.md` — full scope and acceptance criteria.
- `ARENA_AGENT_MASTER_PROMPT.md` — paste this into Arena Agent Mode and attach the PRD/reference images; it directs research, licensed downloads, implementation and QA.
- `ASSET_RESEARCH.md` — researched candidates, license notes, download blockers and decisions.
- `docs/ASSET_LEDGER.md` — included assets and candidates to acquire.
- `QA_REPORT.md` — actual static checks plus engine/device tests still blocked.
- `docs/THIRD_PARTY_CREDITS.md` — credit-template for assets acquired later.
- `docs/MYTHOLOGY_AND_CULTURAL_GUARDRAILS.md` — presentation constraints.
- `docs/QA_TEST_PLAN.md` — import, play, offline and performance tests.
- `assets/reference_art/` — original concept-art reference images (not 3D models).

## Known prototype limitations

- No final rigged Hanuman model or production-ready animation is included.
- The world architecture is procedurally constructed from simple meshes and needs licensed environment detail and art polish.
- Player and sentinel motion are procedural placeholders, not motion-captured animation.
- The save stores completion only; no complex quest-state system, inventory, branching narrative, or checkpointing yet.
- Android export and APK packaging require editor/template/export configuration and real-device testing.
- External DNS/downloads were unavailable during package assembly; no third-party model/prop/audio downloads are claimed as included. The Arena master prompt requires the agent to acquire and validate them in a network-enabled workspace.
